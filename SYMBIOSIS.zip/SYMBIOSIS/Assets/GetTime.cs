﻿using Assets;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Assets
{
    public class GetTime : MonoBehaviour
    {
        public string Time;

        
        // Use this for initialization
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}

